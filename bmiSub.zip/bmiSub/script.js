function submit(){
    let submit=document.getElementById("form")
    submit.addEventListener("submit",(e)=>e.preventDefault())
}
function bmi(){
    document.re

    let weight = document.getElementById("weight").value;
    let height = document.getElementById("height").value;

    let bmires=parseFloat(weight)/parseFloat((height)/100)**2;

    document.getElementById("result").innerHTML="Result"
    document.getElementById("BMI").innerHTML=bmires;

    if(bmires<16){
        document.getElementById("condition").innerHTML="severe Thinness";
    }else if(bmires>=16 && bmires<=17){
        document.getElementById("condition").innerHTML="Moderate Thinness";

    }else if(bmires>=17 && bmires<=18.5){
        document.getElementById("condition").innerHTML="Mild Thinness";
    }else if(bmires>=18.5 && bmires<=25){
        document.getElementById("condition").innerHTML="Normal"
    }else if(bmires>=25 && bmires<=30){
        document.getElementById("condition").innerHTML="Overweight"
    }else if(bmires>=30 && bmires<=35){
        document.getElementById("condition").innerHTML="Obese Class I"
    }else if(bmires>=35 && bmires<=40){
        document.getElementById("condition").innerHTML="Obese Class II"
    }else if(bmires>40){
        document.getElementById("condition").innerHTML="Obese Class III"
    }
}
