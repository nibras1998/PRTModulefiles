import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import {useEffect} from 'react';

function App() {
  useEffect(()=>{
    axios.get("https://jsonplaceholder.typicode.com/posts/").then(res=>{
      console.log(res.data)
    }).catch(err=>{
      console.log(err)
    })
  },[])
  return (
    <div className="App">
        <h2>Fetching data from api in console..</h2>
    </div>
  );
}

export default App;
