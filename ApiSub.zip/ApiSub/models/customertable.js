const mongoose = require('mongoose');

const CustomerSchema = new mongoose.Schema({
    customer_id:{
        type:String,
        unique:true,
        required:true
    },
    customer_name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        unique:true,
        required:true
    },
    balance:{
        type:Number,
        required:true
    }
},
{
    collection:"Customers"
})

module.exports = mongoose.model("Customers",CustomerSchema)