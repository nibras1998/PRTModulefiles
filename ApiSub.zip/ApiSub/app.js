const express = require('express');
const mongoose = require('mongoose');
const ejs = require('ejs');
const app = express();
const port = 3000;

app.set('view engine','ejs');

app.listen(3000,()=>{
    console.log("Server started on port 3000")
})

mongoose.connect("mongodb://localhost:27017/customerApi",()=>{
    console.log("Connected to DB")
})


const Products = require('./models/producttable');

const Customers = require('./models/customertable')

const Orders = require('./models/orders')

app.get('/',(req,res)=>{
    res.send("try apis: /products, /customers")
})

app.get("/products",(req,res)=>{
    Products.find({},(err,docs)=>{
        if(err){
            console.log(err)
        }else{
            res.render('index.ejs',{data:docs})
        }
    })
})

app.get("/product/:id",(req,res)=>{
    let id = req.params.id
    Products.findOne({product_id:id},(err,docs)=>{
        let product = docs
        if(!product){
            res.json({status:"cannot find product with the provided id"})
        }else{
            res.render('product',{docs})
        }
    })
})

app.get("/product/:producttype",(req,res)=>{
    let producttype = req.params.producttype


        Products.find({
        "product_type" : { "$in": ["Electronics",] }
    },(err,docs)=>{
        let product = docs
        if(!product){
            res.json({status:"cannot find product with the provided id"})
        }else{
            res.render('product',{docs})
        }
    })
})


app.get("/customers",(req,res)=>{
    Customers.find({},(err,docs)=>{
        if(err){
            console.log(err)
        }else{
            res.render('customers.ejs',{data:docs})
        }
    })
})

app.get("/customer/:id",(req,res)=>{
    let id = req.params.id
    Customers.findOne({customer_id:id},(err,docs)=>{
        let customer = docs
        if(!customer){
            res.json({status:"cannot customer with the provided id"})
        }else{
            res.render('customer',{docs})
        }
    })
})


