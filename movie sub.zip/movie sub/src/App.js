import logo from './logo.svg';
import './App.css';
import {useState,useEffect} from 'react'
import axios from 'axios'
import 'font-awesome/css/font-awesome.min.css';

function App() {
  const [movies,setMovies] = useState(null)
  const [search,setSearch] = useState(null)
  const [moviesearch,setMovieSearch] = useState(null)
  const [favourites,setFavourites] = useState(null)
  
  useEffect(()=>{
    axios.get("https://www.omdbapi.com/?s=war&apikey=ed197ce8&type=movie")
    .then((res)=>{
      setMovies(res.data.Search)
    })
    .catch((err)=>{
      console.log(err)
    })
  },[])
  
  const handleSearch=()=>{
    axios.get(`https://www.omdbapi.com/?t=${search}&apikey=ed197ce8&type=movie`)
    .then(res=>{
      setMovieSearch(res.data)
    })
    .catch(err=>{
      console.log(err)
    })
  }
  
  
  return (
    <div className="App">
      <div className="container">
        <h1>Movies</h1>
        <input type="text" placeholder='Search for a movie' onChange={e=>setSearch(e.target.value)}/>
        <button className='search' onClick={handleSearch}>Search</button>
        <div className='moviesContainer'>
          {movies&&movies.map((item,i)=>{
            return(
              <div className='movies' key={i} >
              <i className="fa fa-trash-o" aria-hidden="true" style={{
                "color":"white",
                "position":"absolute",
                "padding":"20px",
                "cursor":"pointer"
                }}></i>
              <i className="fa fa-heart" aria-hidden="true" style={{
                "color":"red",
                "position":"absolute",
                "padding-top":"20px",
                "padding-left":"110px",
                "cursor":"pointer"
                }} ></i>
              <img src={item.Poster} alt="Loading"/>
              
              </div>)})}
          
          
        </div>
        {moviesearch?<>
        <h1 id="sm">Search Results</h1>
        <div className='moviesContainer'>
              <div className='movies' >
              <i className="fa fa-trash-o" aria-hidden="true" style={{
                "color":"white",
                "position":"absolute",
                "padding":"20px",
                }}></i>
              <i className="fa fa-heart" aria-hidden="true" style={{
                "color":"red",
                "position":"absolute",
                "padding-top":"20px",
                "padding-left":"110px"
                }}></i>  
              <img
              src={moviesearch.Poster}
              alt="Loading"
            /></div>
        </div></>:null}
       

     
        <h1>Favourites</h1>
        <div className='moviesContainer'>
        {movies&&movies.map((item,i)=>{
            return(
              <div className='movies' key={i} >
              <i className="fa fa-trash-o" aria-hidden="true" style={{
                "color":"white",
                "position":"absolute",
                "padding":"20px",
                "cursor":"pointer"
                }}></i>
              <i className="fa fa-heart" aria-hidden="true" style={{
                "color":"red",
                "position":"absolute",
                "padding-top":"20px",
                "padding-left":"110px",
                "cursor":"pointer"
                }} ></i>
              <img src={item.Poster} alt="Loading"/>
              
              </div>)})}
        </div>
      </div>
    </div>
  );
}

export default App;
