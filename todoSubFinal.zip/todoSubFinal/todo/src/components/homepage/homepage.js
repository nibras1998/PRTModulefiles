import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import './homepage.css'

const Homepage = () => {
    const [value, setValue] = useState("")
    const [input, setInput] = useState(false)
    const [todoStatus, setTodoStatus] = useState("Start")
    const [history, setHistory] = useState([])
    const handleInput = () => {
        setInput(true)

    }
    const [todos, setTodos] = useState([])
    const handleTodo = () => {
        let todo = [...todos, { todo: value, completed: "pending" }]
        setTodos(todo)
        setValue("")
        setInput(false)
    }
    const handleEnd = (todo) => {
        if (todos.some(e => e == todo)) {
            todo.completed = "completed"
            setTodos([...todos])
            setHistory([...history, todo])
        }
    }
    const handlePause = (todo) => {
        if (todos.some(e => e == todo)) {
            todo.completed = "Paused"
            setTodos([...todos])
        }
    }
    const handleStart = (todo) => {
        if (todos.some(e => e == todo)) {
            todo.completed = "Ongoing"
            setTodos([...todos])
        }
    }
    console.log(history)
    return (
        <>
            <div className="containerHome">
                <div className="header">
                    <h4 style={{ "margin-left": "80%" }}>Username</h4>
                </div>
                <div className="containerHomeSide">
                    <p id="add" onClick={handleInput}>Add new activity</p>
                    {input ? <div id="inputContainer">
                        <input id="addtodo" type="text" onChange={(e) => setValue(e.target.value)} />
                        <button onClick={handleTodo}>add</button></div> : null}
                    <div className="sidebar" style={{ "margin": "0px" }}>
                        <h3 style={{ "margin": "0px" }}>To do List</h3>
                        <p style={{ "fontSize": "20px" }}>History</p>
                        <div className="history">
                            {
                                history.map((todo) => {
                                    return (
                                        <p>{todo.todo}</p>
                                    )

                                })
                            }
                        </div>
                        <Link to="/login"><p id="logout">Logout</p></Link>
                    </div>
                    <div className="table">
                        <table>
                            <tr>
                                <th>Activity</th>
                                <th>Status</th>
                                <th>Time taken (Hrs:Min:Sec)</th>
                                <th>Action</th>
                            </tr>
                            {todos.map((todo, id) => {
                                return (
                                    <tr key={id}>
                                        <td>{todo.todo}</td>
                                        <td>{todo.completed}</td>
                                        <td>test</td>
                                        <td>{todo.completed == "pending" || todo.completed == "Paused" ?
                                            <p id="start" onClick={() => handleStart(todo)}>Start</p> : <>
                                                <span id="end" onClick={() => handleEnd(todo)}>End </span>
                                                <span id="pause" onClick={() => handlePause(todo)}> Pause</span>
                                            </>}

                                        </td>
                                    </tr>
                                )
                            })}

                        </table>
                    </div>
                </div>


            </div>
        </>
    )
}
export default Homepage;