import React from "react";
import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import './login.css'

const Login=()=>{
    const [email,setEmail]=useState("")
    const [password,setPassword] = useState("")
    const navigate = useNavigate()
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(!(email,password)){
         return alert("All input is required")
        }
        fetch('http://localhost:5000/login',{
          method:"POST",
          crossDomain:true,
          headers:{
            "Content-Type":"application/json",
            Accept:"application/json","Access-Control-Origin":"*"
          },
          body:JSON.stringify({
            email,
            password
          })
        }).then((res)=>res.json())
        .then((data)=>{
          console.log(data);
          if(data.error==="Invalid password"){
            return alert("Invalid credentials")
          }
          if(data.error==="User Not found"){
            return alert("User does not exist")
          }
          if(data.status === "ok"){
            alert("login successfull");
            window.localStorage.setItem("token", data.token);
            navigate("/home")
          }
          }
        ) 
  
      }
    return(
    <>  
        <div className="circle"></div>
        <div className="container">
            <p style={{"marginTop":"50px","fontSize":"25px"}}>Member Login</p>
            <form>
                <input type="text" style={{"height":"28px","width":"200px","backgroundColor":"lightgrey","border":"none"}} placeholder="Username" onChange={(e)=>setEmail(e.target.value)}/>
                <input type="password" style={{"height":"28px","width":"200px","marginTop":"20px","backgroundColor":"lightgrey","border":"none"}} placeholder="Password" onChange={(e)=>setPassword(e.target.value)}/>
                <br></br><button style={{"height":"32px","width":"205px","marginTop":"20px","backgroundColor":"rgb(70,144,251)","border":"none","color":"white","cursor":"pointer"}} type="submit" onClick={handleSubmit}>Login</button>
            </form>
            <p style={{"color":"red"}}>Forgot Password?</p>
            <Link to="/signup"><p style={{"color":"red"}}>Regsiter</p></Link>
        </div>
    </>
        
    )
}
export default Login;