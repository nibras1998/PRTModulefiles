import axios from "axios";
import React from "react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import './signup.css'

const Signup=()=>{
   const [email,setEmail]=useState("")
   const [password,setPassword]=useState("")
   const [confirmpassword,setConfirmPassword]=useState("")
   const navigate = useNavigate()
   const handleSubmit=(e)=>{
    e.preventDefault()
    if(email==="" || password==="" || confirmpassword===""){
        return alert("All fields are required")
    }
    if(!(email.includes("@"))){
        return alert("Invalid email format")
    }
    if(!(password===confirmpassword)){
        return alert("Passwords does not match")
    }
    fetch('http://localhost:5000/signup',{
        method:"POST",
        crossDomain:true,
        headers:{
          "Content-Type":"application/json",
          Accept:"application/json","Access-Control-Origin":"*"
        },
        body:JSON.stringify({
          email,
          password
        })
      }).then((res)=>res.json())
      .then((data)=>{
        if(data.status==="User already exists"){
          alert("User already exists")
        }else{
          console.log(data)
          navigate("/login")
        }
      })
   } 
    return(
        <>  
        <div className="circle"></div>
        <div className="container">
            <p style={{"marginTop":"50px","fontSize":"25px"}}>Register</p>
            <form>
                <input type="text" style={{"height":"28px","width":"200px","backgroundColor":"lightgrey","border":"none"}} placeholder="Username" onChange={(e)=>setEmail(e.target.value)}/>
                <input type="password" style={{"height":"28px","width":"200px","marginTop":"20px","backgroundColor":"lightgrey","border":"none"}} placeholder="Password" onChange={(e)=>setPassword(e.target.value)}/>
                <input type="password" style={{"height":"28px","width":"200px","marginTop":"20px","backgroundColor":"lightgrey","border":"none"}} placeholder="Confirm Password" onChange={(e)=>setConfirmPassword(e.target.value)}/>
                <br></br>
                <button style={{"height":"32px","width":"205px","marginTop":"20px","backgroundColor":"rgb(70,144,251)","border":"none","color":"white","cursor":"pointer"}} type="submit" onClick={handleSubmit}>Register</button>
            </form>
            <Link to="/login"><p style={{"color":"red"}}>Member Login</p></Link>
        </div>
    </>
    )
}
export default Signup;