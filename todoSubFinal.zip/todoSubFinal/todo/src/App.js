import logo from './logo.svg';
import './App.css';
import Login from './components/login/login';
import Signup from './components/signup/signup';
import {BrowserRouter, Link,Route,Routes} from "react-router-dom";
import Homepage from './components/homepage/homepage';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/signup' element={<Signup/>}/>
        <Route path="/home" element={<Homepage/>}/>
      </Routes>
      </BrowserRouter>
      
    </div>
  );
}

export default App;
