const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express()
require('dotenv').config()
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')


app.use(express.json())
app.use(cors())

app.listen(process.env.PORT || 5000,()=>{
    console.log("Server started on port 5000")
})

mongoose.connect(process.env.mongo_url,()=>{
    console.log("Connected to DB")
})


app.get('/',(req,res)=>{
    res.json({status:"hi"})
})

const User = require('./models/usermodel');

app.get("/",(req,res)=>{
    res.send("Hello")
})

app.post("/signup",async(req,res)=>{
    const {email,password} = req.body;
    const encryptedPassword = await bcrypt.hash(password, 10);

    try {
        const existing = await User.findOne({email});
        if(existing){
            return  res.send({status:"User already exists"})
        }
        await User.create({
            email:email,
            password:encryptedPassword
        });
        res.send({status:"User Created"})
    }catch(error){
        res.send({status:"error"})
    }
})

app.post("/login", async (req, res) => {
    const { email, password } = req.body;
  
    const user = await User.findOne({ email });
    if (!user) {
      return res.json({ error: "User Not found" });
    }
    if(await bcrypt.compare(password,user.password)){
        const token=jwt.sign({data:user._id,exp:Math.floor(Date.now()/1000)+60*60}, JWT_SECRET);
        if(res.status(201)){
            return res.json({ status:"ok", token,user })
        }else{
            return res.json({ error:"error" })
        }
    }
    res.json({status:"error", error:"Invalid password" })
});
