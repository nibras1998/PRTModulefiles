import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import './signup.css'

const Signup=()=>{
    return(
        <>  
        <div className="circle"></div>
        <div className="container">
            <p style={{"marginTop":"50px","fontSize":"25px"}}>Register</p>
            <form>
                <input type="text" style={{"height":"28px","width":"200px","backgroundColor":"lightgrey","border":"none"}} placeholder="Username"/>
                <input type="text" style={{"height":"28px","width":"200px","marginTop":"20px","backgroundColor":"lightgrey","border":"none"}} placeholder="Password"/>
                <input type="text" style={{"height":"28px","width":"200px","marginTop":"20px","backgroundColor":"lightgrey","border":"none"}} placeholder="Confirm Password"/>
                <br></br>
                <button style={{"height":"32px","width":"205px","marginTop":"20px","backgroundColor":"rgb(70,144,251)","border":"none","color":"white","cursor":"pointer"}} type="submit">Register</button>
            </form>
            <Link to="/login"><p style={{"color":"red"}}>Member Login</p></Link>
        </div>
    </>
    )
}
export default Signup;