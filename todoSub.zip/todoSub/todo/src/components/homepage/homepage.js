import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import './homepage.css'

const Homepage=()=>{
    return(
        <>
            <div className="containerHome">
                <div className="header">
                    <h4 style={{"margin-left":"80%"}}>Username</h4>
                </div>
                <div className="containerHomeSide">
                    <p id="add">Add new activity</p>
                <div className="sidebar" style={{"margin":"0px"}}>
                    <h3 style={{"margin":"0px"}}>To do List</h3>
                    <p style={{"fontSize":"20px"}}>History</p>
                    <div className="history">

                    </div>
                    <Link to="/login"><p id="logout">Logout</p></Link>
                </div>
                <div className="table">
                <table>
  <tr>
    <th>Activity</th>
    <th>Status</th>
    <th>Time taken (Hrs:Min:Sec)</th>
    <th>Action</th>
  </tr>
  <tr>
    <td>Test</td>
    <td>test</td>
    <td>test</td>
    <td>Test</td>
  </tr>
</table>
                </div>
                </div>
               

            </div>
        </>
    )
}
export default Homepage;