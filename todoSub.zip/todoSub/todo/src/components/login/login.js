import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import './login.css'

const Login=()=>{
    return(
    <>  
        <div className="circle"></div>
        <div className="container">
            <p style={{"marginTop":"50px","fontSize":"25px"}}>Member Login</p>
            <form>
                <input type="text" style={{"height":"28px","width":"200px","backgroundColor":"lightgrey","border":"none"}} placeholder="Username"/>
                <input type="text" style={{"height":"28px","width":"200px","marginTop":"20px","backgroundColor":"lightgrey","border":"none"}} placeholder="Password"/>
                <Link to="/home"><br></br><button style={{"height":"32px","width":"205px","marginTop":"20px","backgroundColor":"rgb(70,144,251)","border":"none","color":"white","cursor":"pointer"}} type="submit">Login</button></Link>
            </form>
            <p style={{"color":"red"}}>Forgot Password?</p>
            <Link to="/signup"><p style={{"color":"red"}}>Regsiter</p></Link>
        </div>
    </>
        
    )
}
export default Login;