import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import twelvedata from "twelvedata";

function App() {
  const [test,setTest]=useState(null)
  const config = {
    key: "3382f0eff299479784e369ef9c4ee079",
  };
  const client = twelvedata(config);
  useEffect(()=>{
    let params = {
      symbol: "AAPL",
      interval: "1day",
      outputsize: 365,
    };
    
    client
      .timeSeries(params)
      .then((data) => {
        console.log(data.values)
        setTest(data.values)
      })
      .catch((error) => {
        console.log(error)
      });
      console.log(test)
  },[])
  
  return (
    <div className="App">
      {test===null?<h2>Loading please wait...</h2>:
      <table>
      <tr>
        <th>Date</th>
        <th>Open</th>
        <th>High</th>
        <th>Low</th>
        <th>Close</th>
      </tr>
      {test.map((data)=>(
        <tr>
        <td>{data.datetime}</td>
        <td>{data.open}</td>
        <td>{data.high}</td>
        <td>{data.low}</td>
        <td>{data.close}</td>
      </tr>
      ))}
      
      </table>
    
      }

    </div>
  );
}

export default App;
